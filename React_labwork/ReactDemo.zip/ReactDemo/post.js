function Post(props)
{
    return (
        <div>
            {props.name}
            <img src={props.image}></img>
        </div>

    );
}