function App(props)
{

    const [posts, setPosts] = React.useState([]);

    return(
        <div>
            <input id="name" type="text" placeholder="Enter name"></input>
            <input id="image" type="text" placeholder="Give image url"></input>

            <button onClick={()=>{
                const name = document.getElementById("name").value;
                const image = document.getElementById("image").value;

                const post = <Post name={name} image={image}/>;
                setPosts([...posts, post])

            }}>Submit</button>

            <div id="posts-container">
                {posts}
            </div>
        </div>
    );
}

ReactDOM.render(<App/>, document.getElementById("root"));